export class Review
{
	id: number;
    bookname: string;
    name: string;
    rating: number;
    review: string;
}